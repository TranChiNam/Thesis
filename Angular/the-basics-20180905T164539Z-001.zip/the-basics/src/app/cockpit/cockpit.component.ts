import { Component, OnInit, Output, EventEmitter } from '@angular/core';
// import { EventEmitter } from 'events';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.less']
})
export class CockpitComponent implements OnInit {
  @Output() serverCreated = new EventEmitter<{type: string, name: string, content: string}>();
  name = '';
  content = '';
  // serversElement = [];


  constructor() { }

  ngOnInit() {
  }

  onAddServer(type) {
    console.log(`type: ${type}, name: ${this.name}, content: ${this.content}`);
    this.serverCreated.emit({type: type, name: this.name, content: this.content});
  }

}
