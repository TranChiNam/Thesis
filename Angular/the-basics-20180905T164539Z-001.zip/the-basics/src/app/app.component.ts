import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  // styles: [`
  //   h3{
  //     color:dodgerblue;
  //   }`]
})
export class AppComponent {
  serversElement = [{type: 'server', name: 'testserver', content: 'content test!'}];


  onServerAdded(data: {type: string, name: string, content: string}) {
    this.serversElement.push({type: data.type, name: data.name, content: data.content});
    console.log(data.type);
  }
  // onRemoveServer(id: number) {
  //   const position = id;
  //   this.servers.splice(position, 1);
  //   // console.log(id + 1);
  //   // console.log(this.servers);
  // }

}
