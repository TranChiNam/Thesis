import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit {

  txtSearch: String = '';
  items: Array<Object> = [];

  constructor() {}

  ngOnInit() {}

  onSearch() {
    const BASE_URL = 'https://www.googleapis.com/books/v1/volumes?q=""';
    fetch(`${BASE_URL}${this.txtSearch}`, { method: 'GET' })
      .then(response => response.json())
      .then(json => {
        const items = json;
        this.items = items.items;
        console.log(this.items);
      });
    // setTimeout(() => {
    //   console.log(this.items);
    // }, 3000);
  }
}
