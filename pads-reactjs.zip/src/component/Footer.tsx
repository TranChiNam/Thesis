import * as React from 'react';

class Footer extends React.Component {
  public render() {
    return (
      <section className="footer">
        <div className="container">
          <div className="row">
            <div className="col-md-4 col-sm-4 col-12">
              <div className="footer-title">
                Thông tin về <span className="website-name">PADS</span>
              </div>
              <div className="footer-index">
                <ul className="list">
                  <li><a href="#">Giới thiệu</a></li>
                  <li><a href="#">Tuyển dụng</a></li>
                  <li><a href="#">Truyền thông</a></li>
                  <li><a href="#">Blog</a></li>
                </ul>
              </div>
            </div>
            <div className="col-md-4 col-sm-4 col-12">
              <div className="footer-title">
                Hỗ trợ khách hàng
              </div>
              <div className="footer-index">
                <ul className="list">
                  <li><a href="#">Trung tâm trợ giúp</a></li>
                  <li><a href="#">An toàn mua bán</a></li>
                  <li><a href="#">Quy định cần biết</a></li>
                  <li><a href="#">Liên hệ hỗ trợ</a></li>
                </ul>
              </div>
            </div>
            <div className="col-md-4 col-sm-4 col-12">
              <div className="footer-title">
                Phiên bản Mobile
              </div>
              <div className="footer-index">
                <ul className="list">
                  <li><a href="#"><img src={require('../assets/images/ios-app.png')} alt="ios"/></a></li>
                  <li><a href="#"><img src={require('../assets/images/android-app.png')} alt="android"/></a></li>
                </ul>
              </div>
            </div>
          </div>
          <hr />
          <div className="copy-right">
            <div className="item-left">
              @Copy right 2018. Thesis of Tran Chi Nam & Nguyen Thi Nhu Huynh
            </div>
            <div className="item-right">
              <span>Follow us </span>
              <i className="icon-facebook" />
              <i className="icon-twitter" />
              <i className="icon-linkedin2" />
              <i className="icon-google-plus" />
              <i className="icon-github" />
            </div>
          </div>
        </div>
      </section>

    );
  }
}

export default Footer;