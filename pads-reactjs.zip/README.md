# PadsReactJs
This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Install packages
npm i

## Development server
npm start => Navigate to `http://localhost:3000/`
