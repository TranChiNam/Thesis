# PadsAngular
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.1.1.

## Install packages
npm i

## Development server
ng serve => Navigate to `http://localhost:4200/`
